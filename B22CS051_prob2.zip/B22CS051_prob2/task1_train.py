# ============================================================
# TASK 1: TRAIN ALL THREE MODELS
# Run this AFTER task0_dataset.py and task1_models.py
#
# What this cell does:
#   1. Loads TrainingNames.txt
#   2. Builds character vocabulary
#   3. Trains VanillaRNN, BiLSTM, and AttentionRNN
#   4. Saves results to JSON files for Task 2
#   5. Prints architecture info and training progress
# ============================================================

import numpy as np
import random
import json
import time
import os

# ── Import model classes from task1_models.py ───────────────
# (In Colab: run the task1_models.py cell first, or use exec)
from task1_models import (VanillaRNN, BidirectionalLSTM, AttentionRNN,
                           build_vocab, prepare_sequences, SOS, EOS, PAD)

# ── Reproducibility ──────────────────────────────────────────
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

# ════════════════════════════════════════════════════════════
# HYPERPARAMETERS
# ════════════════════════════════════════════════════════════
EMBED_DIM   = 32     # character embedding dimension
HIDDEN_SIZE = 128    # RNN hidden units (per direction for BiLSTM)
LEARNING_RATE = 0.003
NUM_EPOCHS  = 50     # training epochs (increase for better results)
MAX_LEN     = 20     # max characters per name (including SOS/EOS)
TEMPERATURE = 0.8    # sampling temperature for generation
NUM_GENERATE = 200   # names to generate per model (for evaluation)


# ════════════════════════════════════════════════════════════
# STEP 1: LOAD DATASET
# ════════════════════════════════════════════════════════════
with open("TrainingNames.txt", "r") as f:
    names = [line.strip() for line in f if line.strip()]

print(f"✅ Loaded {len(names)} names from TrainingNames.txt")
print(f"   Sample: {names[:8]}\n")


# ════════════════════════════════════════════════════════════
# STEP 2: BUILD VOCABULARY
# ════════════════════════════════════════════════════════════
char2idx, idx2char = build_vocab(names)
V       = len(char2idx)
sos_idx = char2idx[SOS]
eos_idx = char2idx[EOS]
pad_idx = char2idx[PAD]
train_set = set(n.lower() for n in names)

print(f"✅ Vocabulary size : {V} unique characters")
print(f"   Characters      : {''.join(sorted(char2idx.keys()))}")
print(f"   SOS={sos_idx}, EOS={eos_idx}, PAD={pad_idx}\n")

# Save vocabulary for use in evaluation script
with open("vocab.json", "w") as f:
    json.dump({
        "char2idx" : char2idx,
        "idx2char" : {str(k): v for k, v in idx2char.items()},
        "sos_idx"  : sos_idx,
        "eos_idx"  : eos_idx,
        "pad_idx"  : pad_idx,
        "V"        : V
    }, f)
print("✅ Saved vocabulary → vocab.json\n")


# ════════════════════════════════════════════════════════════
# STEP 3: PREPARE TRAINING SEQUENCES
# ════════════════════════════════════════════════════════════
sequences = prepare_sequences(names, char2idx, max_len=MAX_LEN)
print(f"✅ Prepared {len(sequences)} training sequences (max_len={MAX_LEN})\n")


# ════════════════════════════════════════════════════════════
# STEP 4: INSTANTIATE MODELS
# ════════════════════════════════════════════════════════════
models = {
    "VanillaRNN"  : VanillaRNN(V, embed_dim=EMBED_DIM, hidden_size=HIDDEN_SIZE, lr=LEARNING_RATE),
    "BiLSTM"      : BidirectionalLSTM(V, embed_dim=EMBED_DIM, hidden_size=64, lr=LEARNING_RATE),
    "AttentionRNN": AttentionRNN(V, embed_dim=EMBED_DIM, hidden_size=HIDDEN_SIZE, lr=LEARNING_RATE),
}

# Note: BiLSTM uses hidden_size=64 per direction → 128 total context,
# comparable to the other models which use hidden_size=128.


# ════════════════════════════════════════════════════════════
# STEP 5: PRINT ARCHITECTURE INFO
# ════════════════════════════════════════════════════════════
print("=" * 65)
print("TASK 1 — MODEL ARCHITECTURE SUMMARY")
print("=" * 65)
print(f"{'Model':<18} {'Params':>10}  {'Hidden':>8}  {'Layers':>7}  {'LR':>8}")
print("-" * 65)
hidden_info = {"VanillaRNN": 128, "BiLSTM": "64×2=128", "AttentionRNN": 128}
for mname, m in models.items():
    print(f"{mname:<18} {m.num_params():>10,}  {str(hidden_info[mname]):>8}  {'1':>7}  {LEARNING_RATE:>8}")
print("=" * 65)
print()
print("Architecture Descriptions:")
print("  VanillaRNN   : Embedding → Elman RNN(tanh) → Linear → softmax")
print("  BiLSTM       : Embedding → Fwd-RNN + Bwd-RNN → concat(2H) → Linear → softmax")
print("  AttentionRNN : Embedding → RNN → dot-product causal attention → combine → Linear → softmax")
print()


# ════════════════════════════════════════════════════════════
# STEP 6: TRAINING FUNCTION
# ════════════════════════════════════════════════════════════
def train_model(model, sequences, num_epochs, model_name):
    """
    Train a model for `num_epochs` passes over all sequences.
    Sequences are shuffled each epoch to reduce order bias.
    Returns: list of per-epoch average losses.
    """
    epoch_losses = []
    for epoch in range(1, num_epochs + 1):
        random.shuffle(sequences)
        epoch_loss = 0.0
        for inp, tgt in sequences:
            loss = model.train_step(inp, tgt)
            epoch_loss += loss
        avg_loss = epoch_loss / len(sequences)
        epoch_losses.append(avg_loss)
        if epoch == 1 or epoch % 10 == 0:
            print(f"  [{model_name}] Epoch {epoch:3d}/{num_epochs}  Loss: {avg_loss:.4f}")
    return epoch_losses


# ════════════════════════════════════════════════════════════
# STEP 7: TRAIN ALL MODELS
# ════════════════════════════════════════════════════════════
all_losses = {}

for mname, model in models.items():
    print(f"\n{'─'*55}")
    print(f"▶ Training {mname}")
    print(f"  Hyperparams: embed={EMBED_DIM}, hidden={model.H}, "
          f"lr={LEARNING_RATE}, epochs={NUM_EPOCHS}")
    print(f"{'─'*55}")
    t0 = time.time()
    losses = train_model(model, sequences, NUM_EPOCHS, mname)
    elapsed = time.time() - t0
    all_losses[mname] = losses
    print(f"  ✅ Done in {elapsed:.1f}s | Final loss: {losses[-1]:.4f}")


# ════════════════════════════════════════════════════════════
# STEP 8: GENERATE SAMPLE NAMES & SAVE RESULTS
# ════════════════════════════════════════════════════════════
def generate_names(model, sos_idx, eos_idx, idx2char, n=200, temp=0.8):
    """Generate n names and decode them from index lists to strings."""
    names_out = []
    for _ in range(n):
        ids = model.generate(sos_idx, eos_idx, temperature=temp, max_len=15)
        if ids:
            name = "".join(idx2char[i] for i in ids).capitalize()
            names_out.append(name)
    return names_out


print("\n" + "=" * 55)
print("GENERATING SAMPLE NAMES FROM EACH MODEL")
print("=" * 55)

all_generated = {}
results_summary = {}

for mname, model in models.items():
    gen_names = generate_names(model, sos_idx, eos_idx, idx2char,
                               n=NUM_GENERATE, temp=TEMPERATURE)
    all_generated[mname] = gen_names

    # Quick metrics preview
    nov = len([n for n in gen_names if n.lower() not in train_set]) / max(len(gen_names), 1)
    div = len(set(gen_names)) / max(len(gen_names), 1)

    results_summary[mname] = {
        "params"         : model.num_params(),
        "embed_dim"      : EMBED_DIM,
        "hidden_size"    : model.H,
        "learning_rate"  : LEARNING_RATE,
        "epochs"         : NUM_EPOCHS,
        "final_loss"     : round(all_losses[mname][-1], 4),
        "novelty_rate"   : round(nov, 4),
        "diversity"      : round(div, 4),
        "num_generated"  : len(gen_names),
    }

    # Show 10 samples
    samples = list(dict.fromkeys(gen_names))[:10]
    print(f"\n{mname} (params={model.num_params():,}):")
    print(f"  {',  '.join(samples)}")

    # Save generated names to file
    out_file = f"generated_{mname}.txt"
    with open(out_file, "w") as f:
        for n in gen_names:
            f.write(n + "\n")
    print(f"  → Saved {len(gen_names)} names to {out_file}")

# Save training metadata for Task 2
with open("training_results.json", "w") as f:
    json.dump(results_summary, f, indent=2)
with open("training_losses.json", "w") as f:
    json.dump(all_losses, f)

print("\n✅ Saved training_results.json and training_losses.json")
print("\n✅ Task 1 complete! Run task2_evaluate.py next.")