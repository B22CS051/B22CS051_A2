import json
import os
import numpy as np
import matplotlib.pyplot as plt
from collections import Counter

# LOAD DATA
with open("TrainingNames.txt") as f:
    training_names = [l.strip() for l in f if l.strip()]
training_set = set(n.lower() for n in training_names)

with open("evaluation_metrics.json") as f:
    metrics = json.load(f)

MODEL_NAMES = ["VanillaRNN", "BiLSTM", "AttentionRNN"]

all_generated = {}
for mname in MODEL_NAMES:
    fpath = f"generated_{mname}.txt"
    if os.path.exists(fpath):
        with open(fpath) as f:
            all_generated[mname] = [l.strip() for l in f if l.strip()]
    else:
        print(f" {fpath} not found. Run task1_train.py first.")
        all_generated[mname] = []


# HELPER FUNCTIONS FOR QUALITATIVE CHECKS
def is_realistic(name: str) -> bool:
    if not name.isalpha():
        return False
    if not (3 <= len(name) <= 15):
        return False
    vowels = set('aeiouAEIOU')
    if not any(c in vowels for c in name):
        return False
    # Check for excessive character repetition (e.g. "Aaaaaaa")
    for i in range(len(name) - 3):
        if name[i] == name[i+1] == name[i+2] == name[i+3]:
            return False
    return True


def categorise_failures(generated: list) -> dict:
    failures = {
        "too_short"  : [],   # < 3 chars
        "too_long"   : [],   # > 15 chars
        "non_alpha"  : [],   # contains non-letter chars
        "no_vowel"   : [],   # no vowel (unpronounceable)
        "repetitive" : [],   # excessive char repetition
    }
    vowels = set('aeiouAEIOU')
    for name in generated:
        if len(name) < 3:
            failures["too_short"].append(name)
        elif len(name) > 15:
            failures["too_long"].append(name)
        elif not name.isalpha():
            failures["non_alpha"].append(name)
        elif not any(c in vowels for c in name):
            failures["no_vowel"].append(name)
        else:
            has_repetition = any(
                name[i] == name[i+1] == name[i+2] == name[i+3]
                for i in range(len(name) - 3)
                if i + 3 < len(name)
            )
            if has_repetition:
                failures["repetitive"].append(name)
    return failures


def realism_score(generated: list) -> float:
    if not generated:
        return 0.0
    return sum(1 for n in generated if is_realistic(n)) / len(generated)


def most_common_bigrams(generated: list, top_n: int = 10) -> list:
    bigrams = Counter()
    for name in generated:
        name_lower = name.lower()
        for i in range(len(name_lower) - 1):
            bigrams[name_lower[i:i+2]] += 1
    return bigrams.most_common(top_n)


def name_starts(generated: list, top_n: int = 8) -> list:
    starts = Counter(n[0].upper() for n in generated if n)
    return starts.most_common(top_n)


def name_endings(generated: list, top_n: int = 8) -> list:
    ends = Counter(n[-1].lower() for n in generated if n)
    return ends.most_common(top_n)


# TASK 3A: REPRESENTATIVE SAMPLES
print("TASK 3: QUALITATIVE ANALYSIS")

for mname in MODEL_NAMES:
    gen = all_generated[mname]
    # Select 30 unique realistic-looking names as representative samples
    realistic = [n for n in gen if is_realistic(n)]
    unique_realistic = list(dict.fromkeys(realistic))[:30]
    unique_all = list(dict.fromkeys(gen))[:30]

    print(f" {mname}  —  Representative Samples")

    # Show 30 samples in rows of 5
    sample_list = unique_realistic if unique_realistic else unique_all
    for i in range(0, min(30, len(sample_list)), 5):
        row = sample_list[i:i+5]
        print("   " + "   |   ".join(f"{n:<14}" for n in row))


# TASK 3B: REALISM ASSESSMENT
print("TASK 3B: REALISM ASSESSMENT")
print(f"\n{'Model':<18} {'Realism%':>10} {'AvgLen':>8} {'CharDiv':>10} "
      f"{'Starts':>25}  {'Endings':>25}")

for mname in MODEL_NAMES:
    gen = all_generated[mname]
    rs  = realism_score(gen)
    m   = metrics[mname]
    starts  = ", ".join(f"{c}({n})" for c, n in name_starts(gen, 5))
    endings = ", ".join(f"{c}({n})" for c, n in name_endings(gen, 5))
    print(f"{mname:<18} {rs:>9.2%} {m['avg_length']:>8.1f} "
          f"{m['char_diversity']:>10.2f}   {starts:<25}  {endings:<25}")

print("\nRealism check criteria:")
print("   Alphabetic characters only")
print("   Length between 3 and 15 characters")
print("   Contains at least one vowel")
print("   No run of 4+ identical consecutive characters")


# TASK 3C: FAILURE MODE ANALYSIS
print("TASK 3C: COMMON FAILURE MODES")

failure_report = {}
for mname in MODEL_NAMES:
    gen = all_generated[mname]
    fail = categorise_failures(gen)
    failure_report[mname] = fail
    total = len(gen)

    print(f"\n  {mname}  (Total generated: {total})")
    print(f"   {'Failure Type':<22} {'Count':>7}  {'Rate':>8}  {'Examples'}")
    for ftype, examples in fail.items():
        rate = len(examples) / total if total else 0
        ex_str = ", ".join(examples[:4]) if examples else "—"
        print(f"   {ftype:<22} {len(examples):>7}  {rate:>7.2%}  {ex_str}")

    # Duplicate analysis
    dupes = len(gen) - len(set(gen))
    print(f"   {'duplicates':<22} {dupes:>7}  {dupes/total:>7.2%}  "
          f"{'(model keeps repeating names)' if dupes > 5 else '(good variety)'}")

# TASK 3D: BIGRAM PATTERN ANALYSIS
print("TASK 3D: CHARACTER BIGRAM PATTERNS (top 8 per model)")
# Reference: most common bigrams in training data
train_bigrams = Counter()
for n in training_names:
    for i in range(len(n) - 1):
        train_bigrams[n.lower()[i:i+2]] += 1
print(f"\n  Training data top bigrams: "
      f"{', '.join(bg for bg,_ in train_bigrams.most_common(8))}")

for mname in MODEL_NAMES:
    gen = all_generated[mname]
    bgs = most_common_bigrams(gen, 8)
    bg_str = ", ".join(f"{bg}({c})" for bg, c in bgs)
    print(f"  {mname:<18}: {bg_str}")

# TASK 3E: VISUALISATION
colors = {"VanillaRNN": "blue", "BiLSTM": "green", "AttentionRNN": "red"}

fig, axes = plt.subplots(2, 3, figsize=(18, 10))
fig.suptitle("Task 3: Qualitative Analysis Visualisations", fontsize=14, fontweight='bold')

# ── Row 1: Length distributions 
for i, mname in enumerate(MODEL_NAMES):
    ax = axes[0, i]
    gen = all_generated[mname]
    lengths = [len(n) for n in gen]
    train_len = [len(n) for n in training_names]
    ax.hist(train_len, bins=range(2, 20), alpha=0.4, color='gray',
            label='Training', density=True)
    ax.hist(lengths, bins=range(2, 20), alpha=0.7,
            color=colors[mname], label=mname, density=True)
    ax.set_xlabel("Name Length (chars)")
    ax.set_ylabel("Density")
    ax.set_title(f"{mname}\nLength Distribution")
    ax.legend(fontsize=8)
    ax.set_xlim(0, 20)

# ── Row 2: Failure mode stacked bar 
ax_fail = axes[1, 0]
fail_cats = ["too_short", "too_long", "non_alpha", "no_vowel", "repetitive"]
fail_colors = ['#EF5350', '#FF9800', '#9C27B0', '#2196F3', "#599D39"]
bottoms = np.zeros(len(MODEL_NAMES))
x = np.arange(len(MODEL_NAMES))
for fc, fc_color in zip(fail_cats, fail_colors):
    vals = [len(failure_report[m][fc]) for m in MODEL_NAMES]
    ax_fail.bar(x, vals, bottom=bottoms, label=fc.replace('_', ' '),
                color=fc_color, alpha=0.8, edgecolor='black', linewidth=0.5)
    bottoms += np.array(vals)
ax_fail.set_xticks(x); ax_fail.set_xticklabels(MODEL_NAMES, rotation=15, fontsize=9)
ax_fail.set_title("Failure Mode Breakdown"); ax_fail.set_ylabel("Count")
ax_fail.legend(fontsize=8, loc='upper right')

# ── Row 2: Realism score 
ax_real = axes[1, 1]
real_vals = [realism_score(all_generated[m]) * 100 for m in MODEL_NAMES]
bars = ax_real.bar(MODEL_NAMES, real_vals,
                   color=[colors[m] for m in MODEL_NAMES], alpha=0.8, edgecolor='black')
ax_real.set_title("Realism Score"); ax_real.set_ylabel("Realistic Names (%)")
ax_real.set_ylim(0, 110); ax_real.grid(axis='y', alpha=0.3)
ax_real.tick_params(axis='x', rotation=15)
for bar, val in zip(bars, real_vals):
    ax_real.text(bar.get_x() + bar.get_width()/2, val + 1,
                 f'{val:.1f}%', ha='center', fontsize=10, fontweight='bold')

# ── Row 2: First-character distribution 
ax_start = axes[1, 2]
for mname in MODEL_NAMES:
    starts = Counter(n[0].upper() for n in all_generated[mname] if n)
    top_chars = [c for c, _ in starts.most_common(8)]
    vals = [starts[c] for c in top_chars]
    ax_start.plot(top_chars, vals, marker='o', label=mname,
                  color=colors[mname], linewidth=2)
train_starts = Counter(n[0].upper() for n in training_names)
top_train = [c for c, _ in train_starts.most_common(8)]
ax_start.plot(top_train, [train_starts[c] for c in top_train],
              marker='s', label='Training', color='gray',
              linewidth=1.5, linestyle='--')
ax_start.set_xlabel("First Character"); ax_start.set_ylabel("Count")
ax_start.set_title("Name Starting Characters (Top 8)")
ax_start.legend(fontsize=8); ax_start.grid(True, alpha=0.3)

plt.tight_layout()
plt.savefig("task3_qualitative.png", dpi=150, bbox_inches='tight')
plt.show()
print("\nSaved qualitative analysis chart → task3_qualitative.png")

# FINAL SUMMARY TABLE
print("FINAL COMPARISON SUMMARY")
print(f"{'Model':<18} {'Novelty':>9} {'Diversity':>11} {'Validity':>10} "
      f"{'Realism':>9} {'AvgLen':>8}")
for mname in MODEL_NAMES:
    m = metrics[mname]
    rs = realism_score(all_generated[mname])
    print(f"{mname:<18} {m['novelty_rate']:>8.2%} {m['diversity']:>10.2%} "
          f"{m['validity_rate']:>9.2%} {rs:>8.2%} {m['avg_length']:>8.1f}")


