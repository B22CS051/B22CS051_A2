# ============================================================
# TASK 1: MODEL IMPLEMENTATIONS (models.py)
# Three character-level name generation models built from
# scratch using only NumPy — no PyTorch required.
#
# Run this cell FIRST before Task 1 training cells.
# It defines all model classes used later.
# ============================================================

import numpy as np
import random

# ── Reproducibility ──────────────────────────────────────────
SEED = 42
random.seed(SEED)
np.random.seed(SEED)

# ── Special tokens ────────────────────────────────────────────
SOS = '<'   # Start-Of-Sequence token (prepended to every input)
EOS = '>'   # End-Of-Sequence token   (marks name completion)
PAD = '_'   # Padding token           (fills short sequences)


# ════════════════════════════════════════════════════════════
# UTILITY FUNCTIONS
# ════════════════════════════════════════════════════════════

def softmax(x):
    """
    Numerically stable softmax.
    Subtracts max(x) before exp to prevent overflow.
    """
    e = np.exp(x - x.max())
    return e / e.sum()


def build_vocab(names):
    """
    Build character-level vocabulary from a list of name strings.

    Returns:
      char2idx : dict  char → int index
      idx2char : dict  int  → char
    """
    charset = sorted(set(c for name in names for c in name))
    all_chars = [PAD, SOS, EOS] + charset          # reserve 0,1,2 for specials
    char2idx = {c: i for i, c in enumerate(all_chars)}
    idx2char = {i: c for c, i in char2idx.items()}
    return char2idx, idx2char


def prepare_sequences(names, char2idx, max_len=20):
    """
    Encode names into (input, target) integer index pairs.

    Input  : [SOS] + name characters        (teacher-forced input)
    Target : name characters + [EOS]        (next-char prediction target)

    PAD positions are marked with -1 so the loss can skip them.
    """
    pad_idx = char2idx[PAD]
    sos_idx = char2idx[SOS]
    eos_idx = char2idx[EOS]
    sequences = []
    for name in names:
        encoded = [char2idx[c] for c in name if c in char2idx]
        inp = ([sos_idx] + encoded)[:max_len]
        tgt = (encoded + [eos_idx])[:max_len]
        # Zero-pad both sequences to max_len
        inp = inp + [pad_idx] * (max_len - len(inp))
        # Mark pad positions as -1 so cross-entropy ignores them
        tgt = [t if t != pad_idx else -1
               for t in tgt + [-1] * (max_len - len(tgt))]
        sequences.append((inp, tgt))
    return sequences


# ════════════════════════════════════════════════════════════
# MODEL 1 — VANILLA RNN (Elman Network)
# ════════════════════════════════════════════════════════════
class VanillaRNN:
    """
    Single-layer Elman Recurrent Neural Network.

    ARCHITECTURE:
      x_t       = Embedding[char_t]              shape: (E,)
      h_t       = tanh(Wxh @ x_t + Whh @ h_{t-1} + bh)   shape: (H,)
      logit_t   = Why @ h_t + by                 shape: (V,)
      p_t       = softmax(logit_t)

    HYPERPARAMETERS:
      embed_dim   (E) = 32
      hidden_size (H) = 128
      num_layers      = 1
      learning_rate   = 0.003
      optimizer       = Adam

    TRAINABLE PARAMETERS:
      We  : (V, E)      — character embeddings
      Wxh : (H, E)      — input → hidden weights
      Whh : (H, H)      — hidden → hidden (recurrent) weights
      bh  : (H,)        — hidden bias
      Why : (V, H)      — hidden → output weights
      by  : (V,)        — output bias
    """

    def __init__(self, vocab_size, embed_dim=32, hidden_size=128, lr=0.003):
        self.V  = vocab_size
        self.E  = embed_dim
        self.H  = hidden_size
        self.lr = lr

        # Xavier-style initialisation keeps gradients stable at the start
        scale_xe = np.sqrt(2.0 / (embed_dim + hidden_size))
        scale_hh = np.sqrt(2.0 / (2 * hidden_size))

        self.We  = np.random.randn(vocab_size, embed_dim) * 0.01
        self.Wxh = np.random.randn(hidden_size, embed_dim)  * scale_xe
        self.Whh = np.random.randn(hidden_size, hidden_size) * scale_hh
        self.bh  = np.zeros(hidden_size)
        self.Why = np.random.randn(vocab_size, hidden_size) * np.sqrt(2.0 / hidden_size)
        self.by  = np.zeros(vocab_size)

        # Adam optimiser moment buffers (m = 1st moment, v = 2nd moment)
        self._t = 0
        self._b1, self._b2, self._eps = 0.9, 0.999, 1e-8
        param_names = ['We', 'Wxh', 'Whh', 'bh', 'Why', 'by']
        self._m = {p: np.zeros_like(getattr(self, p)) for p in param_names}
        self._v = {p: np.zeros_like(getattr(self, p)) for p in param_names}

    def _adam_update(self, name, grad):
        """Apply one Adam step: bias-corrected gradient descent."""
        self._t += 1
        g = grad
        self._m[name] = self._b1 * self._m[name] + (1 - self._b1) * g
        self._v[name] = self._b2 * self._v[name] + (1 - self._b2) * g ** 2
        m_hat = self._m[name] / (1 - self._b1 ** self._t)
        v_hat = self._v[name] / (1 - self._b2 ** self._t)
        setattr(self, name,
                getattr(self, name) - self.lr * m_hat / (np.sqrt(v_hat) + self._eps))

    def train_step(self, inp, tgt):
        """
        One BPTT (Backpropagation Through Time) step.

        Forward pass  : compute hidden states and output probabilities.
        Backward pass : unroll gradients back through time.
        Update        : Adam step on all parameters.

        Returns: scalar cross-entropy loss for this sequence.
        """
        T = len(inp)
        H = self.H

        # ── Forward pass ──────────────────────────────────────
        # Store embeddings and hidden states for BPTT
        xs = {}
        hs = {-1: np.zeros(H)}    # h_{-1} = zero initial state
        ps = {}

        for t, idx in enumerate(inp):
            xs[t] = self.We[idx]                              # embed char
            hs[t] = np.tanh(self.Wxh @ xs[t] + self.Whh @ hs[t-1] + self.bh)
            logit  = self.Why @ hs[t] + self.by
            ps[t]  = softmax(logit)

        # ── Backward pass (BPTT) ─────────────────────────────
        dWe  = np.zeros_like(self.We)
        dWxh = np.zeros_like(self.Wxh)
        dWhh = np.zeros_like(self.Whh)
        dbh  = np.zeros_like(self.bh)
        dWhy = np.zeros_like(self.Why)
        dby  = np.zeros_like(self.by)
        dh_next = np.zeros(H)    # gradient flowing from the next timestep

        loss = 0.0
        for t in reversed(range(T)):
            if tgt[t] < 0:            # skip PAD positions
                continue
            loss += -np.log(ps[t][tgt[t]] + 1e-9)

            # Gradient of cross-entropy + softmax (combined derivative)
            dy = ps[t].copy()
            dy[tgt[t]] -= 1.0

            # Output layer gradients
            dWhy += np.outer(dy, hs[t])
            dby  += dy

            # Gradient into hidden state (from output + future timestep)
            dh = self.Why.T @ dy + dh_next

            # tanh gradient: d/dx tanh(x) = 1 - tanh(x)^2
            dh_raw = (1.0 - hs[t] ** 2) * dh

            # Accumulate RNN weight gradients
            dbh  += dh_raw
            dWxh += np.outer(dh_raw, xs[t])
            dWhh += np.outer(dh_raw, hs[t-1])
            dWe[inp[t]] += self.Wxh.T @ dh_raw

            # Pass gradient to previous timestep
            dh_next = self.Whh.T @ dh_raw

        # Clip gradients to prevent the "exploding gradient" problem
        for g in [dWe, dWxh, dWhh, dbh, dWhy, dby]:
            np.clip(g, -5, 5, out=g)

        # Adam update for each parameter
        for name, grad in [('We', dWe), ('Wxh', dWxh), ('Whh', dWhh),
                            ('bh', dbh), ('Why', dWhy), ('by', dby)]:
            self._adam_update(name, grad)

        return loss / T

    def generate(self, sos_idx, eos_idx, temperature=0.8, max_len=15):
        """
        Auto-regressive name generation.
        At each step, sample the next character from the predicted distribution.
        Temperature controls randomness: < 1 = sharper, > 1 = more random.
        """
        h   = np.zeros(self.H)
        idx = sos_idx
        out = []
        for _ in range(max_len):
            x   = self.We[idx]
            h   = np.tanh(self.Wxh @ x + self.Whh @ h + self.bh)
            p   = softmax((self.Why @ h + self.by) / temperature)
            idx = np.random.choice(len(p), p=p)
            if idx == eos_idx:
                break
            out.append(idx)
        return out

    def num_params(self):
        """Total number of trainable scalar parameters."""
        return (self.We.size + self.Wxh.size + self.Whh.size +
                self.bh.size  + self.Why.size + self.by.size)


# ════════════════════════════════════════════════════════════
# MODEL 2 — BIDIRECTIONAL RNN (used as BLSTM approximation)
# Two RNN cells: one runs L→R, one runs R→L.
# Outputs are concatenated and projected to vocabulary.
# ════════════════════════════════════════════════════════════
class BidirectionalLSTM:
    """
    True Bidirectional RNN (fwd + bwd Elman cells).

    ARCHITECTURE:
      Forward cell  : h_fwd_t = tanh(Wxf @ x_t + Whf @ h_fwd_{t-1} + bhf)
      Backward cell : h_bwd_t = tanh(Wxb @ x_t + Whb @ h_bwd_{t+1} + bhb)
      Output        : logit_t = Wy @ [h_fwd_t ; h_bwd_t] + by

    The forward cell sees left context, the backward cell sees right context.
    At generation time (no right context available), only the forward cell
    is used — this is the standard practice for BiRNN generation.

    HYPERPARAMETERS:
      embed_dim        (E)  = 32
      hidden_size per dir   = 64   (total context = 128)
      learning_rate         = 0.003
      optimizer             = Adam

    TRAINABLE PARAMETERS:
      We  : (V, E)   — shared embedding
      Wxf, Whf, bhf  — forward  RNN weights
      Wxb, Whb, bhb  — backward RNN weights
      Wy  : (V, 2H)  — output projection (concatenated hidden)
      by  : (V,)
    """

    def __init__(self, vocab_size, embed_dim=32, hidden_size=64, lr=0.003):
        self.V   = vocab_size
        self.E   = embed_dim
        self.H   = hidden_size     # per direction
        self.lr  = lr

        scale = np.sqrt(2.0 / (embed_dim + hidden_size))
        sc_hh = np.sqrt(2.0 / (2 * hidden_size))

        # Shared character embedding
        self.We  = np.random.randn(vocab_size, embed_dim) * 0.01

        # Forward RNN weights (left → right)
        self.Wxf = np.random.randn(hidden_size, embed_dim)  * scale
        self.Whf = np.random.randn(hidden_size, hidden_size) * sc_hh
        self.bhf = np.zeros(hidden_size)

        # Backward RNN weights (right → left)
        self.Wxb = np.random.randn(hidden_size, embed_dim)  * scale
        self.Whb = np.random.randn(hidden_size, hidden_size) * sc_hh
        self.bhb = np.zeros(hidden_size)

        # Output: concatenated [fwd_h ; bwd_h] → vocab
        self.Wy = np.random.randn(vocab_size, 2 * hidden_size) * np.sqrt(2.0 / (2 * hidden_size))
        self.by = np.zeros(vocab_size)

        # Adam state
        self._t = 0
        self._b1, self._b2, self._eps = 0.9, 0.999, 1e-8
        pnames = ['We', 'Wxf', 'Whf', 'bhf', 'Wxb', 'Whb', 'bhb', 'Wy', 'by']
        self._m = {p: np.zeros_like(getattr(self, p)) for p in pnames}
        self._v = {p: np.zeros_like(getattr(self, p)) for p in pnames}

    def _adam(self, name, grad):
        self._t += 1
        g = grad
        self._m[name] = self._b1 * self._m[name] + (1 - self._b1) * g
        self._v[name] = self._b2 * self._v[name] + (1 - self._b2) * g ** 2
        mh = self._m[name] / (1 - self._b1 ** self._t)
        vh = self._v[name] / (1 - self._b2 ** self._t)
        setattr(self, name,
                getattr(self, name) - self.lr * mh / (np.sqrt(vh) + self._eps))

    def _forward_pass(self, inp):
        """Run the forward RNN (L→R) over the input sequence."""
        T = len(inp)
        xs = [self.We[i] for i in inp]
        fhs = {-1: np.zeros(self.H)}
        for t in range(T):
            fhs[t] = np.tanh(self.Wxf @ xs[t] + self.Whf @ fhs[t-1] + self.bhf)
        return xs, fhs

    def _backward_pass(self, inp):
        """Run the backward RNN (R→L) over the input sequence."""
        T = len(inp)
        xs = [self.We[i] for i in inp]
        bhs = {T: np.zeros(self.H)}          # right boundary = zero state
        for t in reversed(range(T)):
            bhs[t] = np.tanh(self.Wxb @ xs[t] + self.Whb @ bhs[t+1] + self.bhb)
        return bhs

    def train_step(self, inp, tgt):
        """
        Full bidirectional forward + BPTT backward.
        Gradients flow through both the forward and backward paths.
        """
        T = len(inp)
        xs, fhs = self._forward_pass(inp)
        bhs = self._backward_pass(inp)

        # Accumulators for all gradients
        dWy = np.zeros_like(self.Wy);  dby  = np.zeros_like(self.by)
        dWxf= np.zeros_like(self.Wxf); dWhf = np.zeros_like(self.Whf)
        dbhf= np.zeros_like(self.bhf)
        dWxb= np.zeros_like(self.Wxb); dWhb = np.zeros_like(self.Whb)
        dbhb= np.zeros_like(self.bhb)
        dWe = np.zeros_like(self.We)
        dh_fwd = np.zeros(self.H)     # carries gradient backward in fwd BPTT
        dh_bwd = np.zeros(self.H)     # carries gradient forward  in bwd BPTT

        loss = 0.0
        for t in reversed(range(T)):
            if tgt[t] < 0:
                continue
            # Concatenate fwd and bwd hidden states for this position
            h_cat = np.concatenate([fhs[t], bhs[t]])
            p = softmax(self.Wy @ h_cat + self.by)
            loss += -np.log(p[tgt[t]] + 1e-9)

            dy = p.copy(); dy[tgt[t]] -= 1.0
            np.clip(dy, -5, 5, out=dy)
            dWy += np.outer(dy, h_cat)
            dby += dy

            # Split gradient into fwd and bwd portions
            dh_full = self.Wy.T @ dy        # (2H,)
            dhf = dh_full[:self.H] + dh_fwd
            dhb = dh_full[self.H:] + dh_bwd

            # Forward RNN BPTT
            drf = (1.0 - fhs[t] ** 2) * dhf
            dbhf += drf
            dWxf += np.outer(drf, xs[t])
            dWhf += np.outer(drf, fhs[t-1])
            dWe[inp[t]] += self.Wxf.T @ drf
            dh_fwd = self.Whf.T @ drf

            # Backward RNN BPTT
            drb = (1.0 - bhs[t] ** 2) * dhb
            dbhb += drb
            dWxb += np.outer(drb, xs[t])
            t_next = t + 1
            dWhb += np.outer(drb, bhs[t_next])
            dWe[inp[t]] += self.Wxb.T @ drb
            dh_bwd = self.Whb.T @ drb

        for g in [dWy, dby, dWxf, dWhf, dbhf, dWxb, dWhb, dbhb, dWe]:
            np.clip(g, -5, 5, out=g)

        for name, grad in [('Wy', dWy), ('by', dby),
                            ('Wxf', dWxf), ('Whf', dWhf), ('bhf', dbhf),
                            ('Wxb', dWxb), ('Whb', dWhb), ('bhb', dbhb),
                            ('We', dWe)]:
            self._adam(name, grad)

        return loss / T

    def generate(self, sos_idx, eos_idx, temperature=0.8, max_len=15):
        """
        Generation uses only the forward RNN cell.
        The backward path needs future tokens (unavailable during generation).
        """
        h   = np.zeros(self.H)
        idx = sos_idx
        out = []
        bwd_dummy = np.zeros(self.H)    # zero stand-in for missing backward state
        for _ in range(max_len):
            x = self.We[idx]
            h = np.tanh(self.Wxf @ x + self.Whf @ h + self.bhf)
            h_cat = np.concatenate([h, bwd_dummy])
            p = softmax((self.Wy @ h_cat + self.by) / temperature)
            idx = np.random.choice(len(p), p=p)
            if idx == eos_idx:
                break
            out.append(idx)
        return out

    def num_params(self):
        return (self.We.size +
                self.Wxf.size + self.Whf.size + self.bhf.size +
                self.Wxb.size + self.Whb.size + self.bhb.size +
                self.Wy.size  + self.by.size)


# ════════════════════════════════════════════════════════════
# MODEL 3 — RNN WITH SELF-ATTENTION
# ════════════════════════════════════════════════════════════
class AttentionRNN:
    """
    Vanilla RNN augmented with causal dot-product self-attention.

    ARCHITECTURE:
      Step 1 — RNN hidden state:
        h_t = tanh(Wxh @ x_t + Whh @ h_{t-1} + bh)

      Step 2 — Attention (causal: only looks at past tokens):
        score_{t,s} = h_t · (Wa @ h_s)        for s ≤ t
        α_{t,s}     = softmax(score_{t,s})     attention weights
        ctx_t       = Σ_s α_{t,s} * h_s        weighted context vector

      Step 3 — Combine:
        combined_t  = tanh(Wc @ [h_t ; ctx_t] + bc)

      Step 4 — Output:
        logit_t     = Wy @ combined_t + by
        p_t         = softmax(logit_t)

    The attention mechanism lets the model "look back" at earlier
    characters when predicting the next one. This is especially useful
    for capturing long-range patterns (e.g. suffix styles).

    HYPERPARAMETERS:
      embed_dim   (E) = 32
      hidden_size (H) = 128
      learning_rate   = 0.003
      optimizer       = Adam

    TRAINABLE PARAMETERS:
      We  : (V, E)    — embeddings
      Wxh : (H, E)    — input → hidden
      Whh : (H, H)    — hidden → hidden (recurrent)
      bh  : (H,)
      Wa  : (H, H)    — attention key projection
      Wc  : (H, 2H)   — context + hidden → combined
      bc  : (H,)
      Wy  : (V, H)    — combined → vocab
      by  : (V,)
    """

    def __init__(self, vocab_size, embed_dim=32, hidden_size=128, lr=0.003):
        self.V  = vocab_size
        self.E  = embed_dim
        self.H  = hidden_size
        self.lr = lr

        scale_xe = np.sqrt(2.0 / (embed_dim + hidden_size))
        scale_hh = np.sqrt(2.0 / (2 * hidden_size))

        self.We  = np.random.randn(vocab_size, embed_dim) * 0.01
        self.Wxh = np.random.randn(hidden_size, embed_dim)  * scale_xe
        self.Whh = np.random.randn(hidden_size, hidden_size) * scale_hh
        self.bh  = np.zeros(hidden_size)

        # Attention: Wa projects key hidden states for compatibility scoring
        # Initialised near identity to avoid disturbing early training
        self.Wa  = np.eye(hidden_size) * 0.1

        # Combine [h_t ; ctx_t] (size 2H) → hidden_size
        self.Wc  = np.random.randn(hidden_size, 2 * hidden_size) * np.sqrt(2.0 / (3 * hidden_size))
        self.bc  = np.zeros(hidden_size)

        self.Wy  = np.random.randn(vocab_size, hidden_size) * np.sqrt(2.0 / hidden_size)
        self.by  = np.zeros(vocab_size)

        # Adam state
        self._t = 0
        self._b1, self._b2, self._eps = 0.9, 0.999, 1e-8
        pnames = ['We', 'Wxh', 'Whh', 'bh', 'Wa', 'Wc', 'bc', 'Wy', 'by']
        self._m = {p: np.zeros_like(getattr(self, p)) for p in pnames}
        self._v = {p: np.zeros_like(getattr(self, p)) for p in pnames}

    def _adam(self, name, grad):
        self._t += 1
        g = grad
        self._m[name] = self._b1 * self._m[name] + (1 - self._b1) * g
        self._v[name] = self._b2 * self._v[name] + (1 - self._b2) * g ** 2
        mh = self._m[name] / (1 - self._b1 ** self._t)
        vh = self._v[name] / (1 - self._b2 ** self._t)
        setattr(self, name,
                getattr(self, name) - self.lr * mh / (np.sqrt(vh) + self._eps))

    def _attend(self, h_t, past_hs):
        """
        Compute attention-weighted context vector.

        h_t     : (H,) — current query hidden state
        past_hs : array (t+1, H) — all past hidden states (causal mask)

        Returns context (H,) and attention weights (t+1,).
        """
        # Project past states through Wa, then dot with query
        proj   = past_hs @ self.Wa.T       # (t+1, H)
        scores = proj @ h_t                 # (t+1,) dot products
        weights = softmax(scores)           # (t+1,) attention distribution
        ctx = weights @ past_hs             # (H,)  weighted sum
        return ctx, weights

    def train_step(self, inp, tgt):
        """
        Forward pass with attention + BPTT.
        """
        T = len(inp)
        H = self.H

        # ── Forward: compute all hidden states ────────────────
        # Store as matrix for efficient attention computation
        hs = np.zeros((T + 1, H))  # hs[0] = zero init; hs[t+1] = h_t
        xs = np.zeros((T, self.E))
        for t, idx in enumerate(inp):
            xs[t] = self.We[idx]
            hs[t+1] = np.tanh(self.Wxh @ xs[t] + self.Whh @ hs[t] + self.bh)

        # ── Forward: attention + output for each position ─────
        # (we store combined outputs for backward pass)
        combos = np.zeros((T, H))
        ctxs   = np.zeros((T, H))
        alphas = []                          # attention weights per timestep

        loss = 0.0
        for t in range(T):
            if tgt[t] < 0:
                alphas.append(None)
                continue
            past = hs[1:t+2]                 # (t+1, H) — causal slice
            ctx, alpha = self._attend(hs[t+1], past)
            ctxs[t] = ctx
            alphas.append(alpha)
            combo = np.tanh(self.Wc @ np.concatenate([hs[t+1], ctx]) + self.bc)
            combos[t] = combo
            p = softmax(self.Wy @ combo + self.by)
            loss += -np.log(p[tgt[t]] + 1e-9)

        # ── Backward pass ─────────────────────────────────────
        dWy  = np.zeros_like(self.Wy)
        dby  = np.zeros_like(self.by)
        dWc  = np.zeros_like(self.Wc)
        dbc  = np.zeros_like(self.bc)
        dWxh = np.zeros_like(self.Wxh)
        dWhh = np.zeros_like(self.Whh)
        dbh  = np.zeros_like(self.bh)
        dWe  = np.zeros_like(self.We)
        dWa  = np.zeros_like(self.Wa)

        for t in reversed(range(T)):
            if tgt[t] < 0:
                continue
            # Re-run forward for this timestep (needed for gradients)
            past = hs[1:t+2]
            ctx  = ctxs[t]
            combo = combos[t]
            p = softmax(self.Wy @ combo + self.by)

            # Output layer gradient
            dy = p.copy(); dy[tgt[t]] -= 1.0
            np.clip(dy, -5, 5, out=dy)
            dWy += np.outer(dy, combo)
            dby += dy

            # Gradient into 'combined' vector
            dcombo = self.Wy.T @ dy * (1.0 - combo ** 2)   # tanh backprop
            np.clip(dcombo, -2, 2, out=dcombo)
            dWc += np.outer(dcombo, np.concatenate([hs[t+1], ctx]))
            dbc += dcombo

            # Split into h_t portion and ctx portion
            dh_t  = self.Wc.T[:H] @ dcombo
            dctx  = self.Wc.T[H:] @ dcombo

            # Attention gradient: approximate update for Wa
            # Full attention BPTT is very expensive; we use a first-order approx
            alpha = alphas[t]
            for s, hs_s in enumerate(past):
                dWa += alpha[s] * np.outer(dctx, hs_s) * 0.01

            # RNN hidden-state gradient
            dh_raw = (1.0 - hs[t+1] ** 2) * dh_t
            np.clip(dh_raw, -2, 2, out=dh_raw)
            dbh  += dh_raw
            dWxh += np.outer(dh_raw, xs[t])
            dWhh += np.outer(dh_raw, hs[t])
            dWe[inp[t]] += self.Wxh.T @ dh_raw

        for g in [dWy, dby, dWc, dbc, dWxh, dWhh, dbh, dWe, dWa]:
            np.clip(g, -5, 5, out=g)

        for name, grad in [('Wy', dWy), ('by', dby), ('Wc', dWc), ('bc', dbc),
                            ('Wxh', dWxh), ('Whh', dWhh), ('bh', dbh),
                            ('We', dWe), ('Wa', dWa)]:
            self._adam(name, grad)

        return loss / T

    def generate(self, sos_idx, eos_idx, temperature=0.8, max_len=15):
        """
        Auto-regressive generation with live attention over all past states.
        The attention context grows as each new character is produced.
        """
        h   = np.zeros(self.H)
        idx = sos_idx
        out = []
        past_hs = [np.zeros(self.H)]     # seed with the zero initial state

        for _ in range(max_len):
            x = self.We[idx]
            h = np.tanh(self.Wxh @ x + self.Whh @ h + self.bh)
            past_hs.append(h.copy())

            past_arr = np.array(past_hs)
            ctx, _ = self._attend(h, past_arr)

            combo = np.tanh(self.Wc @ np.concatenate([h, ctx]) + self.bc)
            p     = softmax((self.Wy @ combo + self.by) / temperature)
            idx   = np.random.choice(len(p), p=p)

            if idx == eos_idx:
                break
            out.append(idx)

        return out

    def num_params(self):
        return (self.We.size + self.Wxh.size + self.Whh.size + self.bh.size +
                self.Wa.size + self.Wc.size  + self.bc.size  +
                self.Wy.size + self.by.size)


# ── Quick self-test when run directly ────────────────────────
if __name__ == "__main__":
    print("=" * 55)
    print("Model Architecture Summary")
    print("=" * 55)
    V = 42   # typical vocab size for Indian names
    models = {
        "VanillaRNN"    : VanillaRNN(V),
        "BiLSTM"        : BidirectionalLSTM(V),
        "AttentionRNN"  : AttentionRNN(V),
    }
    for name, m in models.items():
        print(f"  {name:<20}  Params: {m.num_params():>8,}")
    print("=" * 55)
    print(" All model classes loaded successfully.")