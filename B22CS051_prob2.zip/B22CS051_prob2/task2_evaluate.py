import json
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec


# METRIC FUNCTIONS
def novelty_rate(generated: list, training_set: set) -> float:
    if not generated:
        return 0.0
    novel = [n for n in generated if n.lower() not in training_set]
    return len(novel) / len(generated)


def diversity(generated: list) -> float:
    if not generated:
        return 0.0
    return len(set(generated)) / len(generated)


def validity_rate(generated: list, min_len: int = 3, max_len: int = 15) -> float:
    if not generated:
        return 0.0
    valid = [n for n in generated if n.isalpha() and min_len <= len(n) <= max_len]
    return len(valid) / len(generated)


def avg_length(generated: list) -> float:
    if not generated:
        return 0.0
    return np.mean([len(n) for n in generated])


def character_diversity(generated: list) -> float:
    if not generated:
        return 0.0
    return np.mean([len(set(n.lower())) for n in generated])


# LOAD DATA
with open("TrainingNames.txt") as f:
    training_names = [l.strip() for l in f if l.strip()]
training_set = set(n.lower() for n in training_names)

with open("training_results.json") as f:
    training_results = json.load(f)

with open("training_losses.json") as f:
    all_losses = json.load(f)

MODEL_NAMES = ["VanillaRNN", "BiLSTM", "AttentionRNN"]

# Load generated names
all_generated = {}
for mname in MODEL_NAMES:
    fpath = f"generated_{mname}.txt"
    if os.path.exists(fpath):
        with open(fpath) as f:
            all_generated[mname] = [l.strip() for l in f if l.strip()]
    else:
        print(f"⚠ Warning: {fpath} not found. Run task1_train.py first.")
        all_generated[mname] = []


# COMPUTE ALL METRICS
metrics = {}
for mname in MODEL_NAMES:
    gen = all_generated[mname]
    metrics[mname] = {
        "novelty_rate"      : novelty_rate(gen, training_set),
        "diversity"         : diversity(gen),
        "validity_rate"     : validity_rate(gen),
        "avg_length"        : avg_length(gen),
        "char_diversity"    : character_diversity(gen),
        "total_generated"   : len(gen),
        "unique_count"      : len(set(gen)),
        "novel_count"       : len([n for n in gen if n.lower() not in training_set]),
    }


# PRINT RESULTS TABLE
print("TASK 2: QUANTITATIVE EVALUATION RESULTS")


# Table header
header = (f"{'Model':<18} {'Params':>8} {'Loss':>7} "
          f"{'Novelty':>9} {'Diversity':>11} {'Validity':>10} "
          f"{'AvgLen':>8} {'CharDiv':>9}")
print(header)


for mname in MODEL_NAMES:
    r = training_results[mname]
    m = metrics[mname]
    print(f"{mname:<18} {r['params']:>8,} {r['final_loss']:>7.4f} "
          f"{m['novelty_rate']:>8.2%} {m['diversity']:>10.2%} "
          f"{m['validity_rate']:>9.2%} "
          f"{m['avg_length']:>8.1f} {m['char_diversity']:>9.2f}")

print("=" * 80)

# Detailed table
print("\nDETAILED COUNTS:")
print(f"{'Model':<18} {'Total':>8} {'Unique':>8} {'Novel':>8}")
print("-" * 45)
for mname in MODEL_NAMES:
    m = metrics[mname]
    print(f"{mname:<18} {m['total_generated']:>8} "
          f"{m['unique_count']:>8} {m['novel_count']:>8}")

# SAVE METRICS
with open("evaluation_metrics.json", "w") as f:
    json.dump(metrics, f, indent=2)
print("\n Saved full metrics → evaluation_metrics.json")


# PLOT TRAINING LOSS CURVES + BAR CHARTS
colors = {"VanillaRNN": "blue", "BiLSTM":"green", "AttentionRNN": 'red'}

fig = plt.figure(figsize=(18, 10))
fig.suptitle("Task 2: Model Comparison — Training Loss & Evaluation Metrics",
             fontsize=14, fontweight='bold')

gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

# ── Plot 1: Training Loss curves 
ax1 = fig.add_subplot(gs[0, :2])    # spans first 2 columns
for mname in MODEL_NAMES:
    losses = all_losses[mname]
    ax1.plot(range(1, len(losses)+1), losses,
             label=mname, color=colors[mname], linewidth=2)
ax1.set_xlabel("Epoch")
ax1.set_ylabel("Cross-Entropy Loss")
ax1.set_title("Training Loss Over Epochs")
ax1.legend()
ax1.grid(True, alpha=0.3)

# ── Plot 2: Param count 
ax2 = fig.add_subplot(gs[0, 2])
param_vals = [training_results[m]['params'] for m in MODEL_NAMES]
bars = ax2.bar(MODEL_NAMES, param_vals,
               color=[colors[m] for m in MODEL_NAMES], alpha=0.8, edgecolor='black')
ax2.set_title("Trainable Parameters")
ax2.set_ylabel("Number of Parameters")
ax2.tick_params(axis='x', rotation=15)
for bar, val in zip(bars, param_vals):
    ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 200,
             f'{val:,}', ha='center', va='bottom', fontsize=8)

# ── Plot 3: Novelty & Diversity 
ax3 = fig.add_subplot(gs[1, 0])
x = np.arange(len(MODEL_NAMES))
w = 0.35
nov_vals = [metrics[m]['novelty_rate'] * 100 for m in MODEL_NAMES]
div_vals = [metrics[m]['diversity']    * 100 for m in MODEL_NAMES]
ax3.bar(x - w/2, nov_vals, w, label='Novelty %',  color="#4D9FE2", edgecolor='black')
ax3.bar(x + w/2, div_vals, w, label='Diversity %', color='#81C784', edgecolor='black')
ax3.set_xticks(x); ax3.set_xticklabels(MODEL_NAMES, rotation=15, fontsize=8)
ax3.set_ylabel("Percentage (%)"); ax3.set_title("Novelty vs Diversity")
ax3.legend(fontsize=8); ax3.set_ylim(0, 110); ax3.grid(axis='y', alpha=0.3)
for i, (n, d) in enumerate(zip(nov_vals, div_vals)):
    ax3.text(i - w/2, n + 1, f'{n:.0f}%', ha='center', fontsize=7)
    ax3.text(i + w/2, d + 1, f'{d:.0f}%', ha='center', fontsize=7)

# ── Plot 4: Validity Rate 
ax4 = fig.add_subplot(gs[1, 1])
val_vals = [metrics[m]['validity_rate'] * 100 for m in MODEL_NAMES]
bars4 = ax4.bar(MODEL_NAMES, val_vals,
                color=[colors[m] for m in MODEL_NAMES], alpha=0.8, edgecolor='black')
ax4.set_title("Validity Rate")
ax4.set_ylabel("Percentage (%)")
ax4.set_ylim(0, 110)
ax4.tick_params(axis='x', rotation=15)
ax4.grid(axis='y', alpha=0.3)
for bar, val in zip(bars4, val_vals):
    ax4.text(bar.get_x() + bar.get_width()/2, val + 1,
             f'{val:.1f}%', ha='center', va='bottom', fontsize=9)

# ── Plot 5: Avg Length & Char Diversity 
ax5 = fig.add_subplot(gs[1, 2])
avg_len  = [metrics[m]['avg_length']    for m in MODEL_NAMES]
char_div = [metrics[m]['char_diversity'] for m in MODEL_NAMES]
ax5_r = ax5.twinx()
b1 = ax5.bar(x - w/2, avg_len,  w, label='Avg Length', color='#FF8A65', alpha=0.8, edgecolor='black')
b2 = ax5_r.bar(x + w/2, char_div, w, label='Char Diversity', color='#CE93D8', alpha=0.8, edgecolor='black')
ax5.set_xticks(x); ax5.set_xticklabels(MODEL_NAMES, rotation=15, fontsize=8)
ax5.set_ylabel("Avg Length (chars)"); ax5_r.set_ylabel("Unique Chars / Name")
ax5.set_title("Length & Character Diversity")
lines = [b1, b2]
labels = ['Avg Length', 'Char Diversity']
ax5.legend(lines, labels, fontsize=7)

plt.savefig("task2_evaluation.png", dpi=150, bbox_inches='tight')
plt.show()
print(" Saved evaluation chart → task2_evaluation.png")
